package com.example.moviebooking

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SeatSelectionActivity : AppCompatActivity() {

    private lateinit var confirmButton: Button
    private lateinit var selectedSeatsTextView: TextView
    private lateinit var seatGrid: GridLayout
    private var selectedSeats: String = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seat_selection)

        confirmButton = findViewById(R.id.confirmSeatsButton)
        selectedSeatsTextView = findViewById(R.id.selectedSeatsTextView)
        seatGrid = findViewById(R.id.seatGrid)

        // Dynamically add seat buttons to the GridLayout
        for (i in 1..25) { // 25 seats in total (5 rows, 5 columns)
            val button = Button(this)
            button.text = "Seat $i"
            button.layoutParams = GridLayout.LayoutParams().apply {
                rowSpec = GridLayout.spec((i - 1) / 5)
                columnSpec = GridLayout.spec((i - 1) % 5)
            }
            button.setOnClickListener { view ->
                val seatNumber = (view as Button).text.toString()
                if (selectedSeats.contains(seatNumber)) {
                    selectedSeats = selectedSeats.replace("$seatNumber, ", "")
                } else {
                    selectedSeats += "$seatNumber, "
                }
                selectedSeatsTextView.text = "Selected Seats: $selectedSeats"
            }
            seatGrid.addView(button)
        }

        confirmButton.setOnClickListener {
            val resultIntent = Intent()
            resultIntent.putExtra("SELECTED_SEATS", selectedSeats)
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }
}