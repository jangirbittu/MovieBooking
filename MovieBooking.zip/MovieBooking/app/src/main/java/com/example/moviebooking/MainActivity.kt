package com.example.moviebooking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var movieSpinner: Spinner
    private lateinit var dateSpinner: Spinner
    private lateinit var timeSpinner: Spinner
    private lateinit var seatSelectionButton: Button
    private lateinit var confirmationTextView: TextView

    private var selectedMovie: String? = null
    private var selectedDate: String? = null
    private var selectedTime: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        movieSpinner = findViewById(R.id.movieSpinner)
        dateSpinner = findViewById(R.id.dateSpinner)
        timeSpinner = findViewById(R.id.timeSpinner)
        seatSelectionButton = findViewById(R.id.seatSelectionButton)
        confirmationTextView = findViewById(R.id.confirmationTextView)

        setupSpinners()
        setupSeatSelectionButton()
    }

    private fun setupSpinners() {
        val movies = arrayOf("Movie 1", "Movie 2", "Movie 3")
        val dates = arrayOf("2023-10-01", "2023-10-02", "2023-10-03")
        val times = arrayOf("10:00 AM", "1:00 PM", "4:00 PM")

        movieSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, movies)
        dateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, dates)
        timeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, times)

        movieSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                selectedMovie = movies[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        dateSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                selectedDate = dates[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        timeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                selectedTime = times[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun setupSeatSelectionButton() {
        seatSelectionButton.setOnClickListener {
            if (selectedMovie != null && selectedDate != null && selectedTime != null) {
                Log.d("MainActivity", "Navigating to Seat Selection")
                val intent = Intent(this, SeatSelectionActivity::class.java)
                intent.putExtra("MOVIE", selectedMovie)
                intent.putExtra("DATE", selectedDate)
                intent.putExtra("TIME", selectedTime)
                startActivityForResult(intent, 1)
            } else {
                confirmationTextView.text = "Please select a movie, date, and time."
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode ==  1 && resultCode == RESULT_OK) {
            val selectedSeats = data?.getStringExtra("SELECTED_SEATS")
            confirmationTextView.text = "Booking Confirmed for $selectedMovie on $selectedDate at $selectedTime. Seats: $selectedSeats"
        }
    }
}